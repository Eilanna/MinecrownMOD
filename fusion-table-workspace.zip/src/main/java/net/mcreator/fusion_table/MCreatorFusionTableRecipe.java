package net.mcreator.fusion_table;

public class MCreatorFusionTableRecipe extends fusion_table.ModElement {

	public MCreatorFusionTableRecipe(fusion_table instance) {
		super(instance);
	}
}
