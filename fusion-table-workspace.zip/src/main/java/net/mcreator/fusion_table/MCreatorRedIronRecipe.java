package net.mcreator.fusion_table;

public class MCreatorRedIronRecipe extends fusion_table.ModElement {

	public MCreatorRedIronRecipe(fusion_table instance) {
		super(instance);
	}
}
